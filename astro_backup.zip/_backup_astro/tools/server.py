import os
import re
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from flask import Flask, request, jsonify
from flask_cors import CORS
from bs4 import BeautifulSoup
import requests
from urllib.parse import urljoin, urlparse

app = Flask(__name__)
CORS(app)  # Allow frontend to communicate

# Configuration
CONTENT_DIR = Path(__file__).parent.parent / "src/content/papers"
UPLOAD_FOLDER = Path(__file__).parent / "temp_uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CONTENT_DIR, exist_ok=True)

def sanitize_filename(name):
    """Clean filename to be safe."""
    name = re.sub(r'[/\\:*?"<>|]', "_", name)
    name = name.strip().replace(" ", "-").lower()
    return name

def download_image(url, save_dir):
    """Downloads an image and returns its local filename."""
    try:
        response = requests.get(url, stream=True, timeout=10)
        response.raise_for_status()
        
        # Determine extension
        content_type = response.headers.get('content-type')
        ext = ".jpg"
        if "png" in content_type: ext = ".png"
        elif "gif" in content_type: ext = ".gif"
        elif "webp" in content_type: ext = ".webp"
        
        filename = f"{uuid.uuid4().hex[:8]}{ext}"
        save_path = save_dir / filename
        
        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(1024):
                f.write(chunk)
        
        return filename
    except Exception as e:
        print(f"Error downloading {url}: {e}")
        return None

def process_markdown(content, slug):
    """
    Parses markdown content, finds image links, downloads them,
    and updates the markdown to use local paths.
    """
    # Create directory for this paper
    paper_dir = CONTENT_DIR / slug
    images_dir = paper_dir / "images"
    os.makedirs(images_dir, exist_ok=True)
    
    # Simple regex to find images: ![alt](url)
    # detecting standard markdown images
    image_pattern = r'!\[(.*?)\]\((.*?)\)'
    
    def replace_image(match):
        alt_text = match.group(1)
        url = match.group(2)
        
        # Skip if already local or data URI
        if not url.startswith('http'):
            return match.group(0)
            
        print(f"Downloading: {url}")
        filename = download_image(url, images_dir)
        
        if filename:
            # Return new markdown image syntax with local path relative to the md file
            # In Astro content collections, images are often referenced relative to the file
            return f'![{alt_text}](./images/{filename})'
        return match.group(0)

    new_content = re.sub(image_pattern, replace_image, content)
    
    # Save the processed markdown
    index_path = paper_dir / "index.md"
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
        
    return str(index_path)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file:
        filename = file.filename
        
        # Read content
        content = file.read().decode('utf-8')
        
        # Extract title from YAML frontmatter or first header
        title = "Untitled"
        # Try to find title in frontmatter
        fm_match = re.search(r'^---\n(.*?)\n---', content, re.DOTALL)
        if fm_match:
            fm = fm_match.group(1)
            title_match = re.search(r'title:\s*(.*)', fm)
            if title_match:
                title = title_match.group(1).strip().strip('"')
        
        # Generate slug
        slug = sanitize_filename(title)
        if not slug:
            slug = f"paper-{int(datetime.now().timestamp())}"
            
        processed_path = process_markdown(content, slug)
        
        return jsonify({
            "message": "File processed successfully",
            "path": processed_path,
            "slug": slug
        })

if __name__ == '__main__':
    print("---------------------------------------------------------")
    print("   Digital Museum Curator Server Running on Port 5000")
    print("   Target Directory: src/content/papers/")
    print("---------------------------------------------------------")
    app.run(debug=True, port=5000)
